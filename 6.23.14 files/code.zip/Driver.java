/****************************************************************
Executes CRYPTICON.
****************************************************************/
public class Driver
{
    /****************************************************************
	Initializes the GUI. Post-initialization is handled elsewhere.
	****************************************************************/
	public static void main(String[] args)
	{
		Display.init();
	}
}